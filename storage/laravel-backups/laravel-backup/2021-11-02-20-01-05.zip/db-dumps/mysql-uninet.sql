
/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
DROP TABLE IF EXISTS `abonos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `abonos` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `id_factura` int(11) DEFAULT NULL,
  `id_cliente` int(11) DEFAULT NULL,
  `id_cobrador` int(11) DEFAULT NULL,
  `id_usuario` int(11) DEFAULT NULL,
  `recibo` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `tipo_servicio` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `numero_documento` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `tipo_documento` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `tipo_pago` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `mes_servicio` date DEFAULT NULL,
  `fecha_aplicado` date DEFAULT NULL,
  `fecha_vence` date DEFAULT NULL,
  `cargo` double(8,2) DEFAULT NULL,
  `abono` double(8,2) DEFAULT NULL,
  `cesc_cargo` double(8,2) DEFAULT NULL,
  `cesc_abono` double(8,2) DEFAULT NULL,
  `precio` double(8,2) DEFAULT NULL,
  `anulado` int(11) NOT NULL,
  `pagado` int(11) NOT NULL,
  `exento` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `abonos` WRITE;
/*!40000 ALTER TABLE `abonos` DISABLE KEYS */;
INSERT INTO `abonos` VALUES (1,NULL,2,NULL,NULL,NULL,'1',NULL,NULL,NULL,'2021-09-18','2021-10-18','2021-10-28',14.99,0.00,NULL,NULL,NULL,0,0,NULL,'2021-10-18 06:31:01','2021-10-18 06:31:01'),(2,NULL,1,NULL,NULL,NULL,'1',NULL,NULL,NULL,'2021-09-18','2021-10-18','2021-10-28',17.99,0.00,NULL,NULL,NULL,0,0,NULL,'2021-10-18 06:31:01','2021-10-18 06:31:01'),(3,NULL,2,NULL,NULL,NULL,'1',NULL,NULL,NULL,'2021-09-18','2021-10-18','2021-10-28',14.99,0.00,NULL,NULL,NULL,0,0,NULL,'2021-10-18 08:00:02','2021-10-18 08:00:02'),(4,NULL,1,NULL,NULL,NULL,'1',NULL,NULL,NULL,'2021-09-18','2021-10-18','2021-10-28',17.99,0.00,NULL,NULL,NULL,0,0,NULL,'2021-10-18 08:00:02','2021-10-18 08:00:02'),(5,NULL,9,NULL,NULL,NULL,'1',NULL,NULL,NULL,'2021-09-21','2021-10-21','2021-10-31',11.99,0.00,NULL,NULL,NULL,0,0,NULL,'2021-10-21 08:00:01','2021-10-21 08:00:01'),(6,NULL,9,NULL,NULL,NULL,'2',NULL,NULL,NULL,'2021-09-21','2021-10-21','2021-10-31',15.00,0.00,NULL,NULL,NULL,0,0,NULL,'2021-10-21 08:00:01','2021-10-21 08:00:01');
/*!40000 ALTER TABLE `abonos` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `actividades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `actividades` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `actividad` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `descripcion` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `actividades` WRITE;
/*!40000 ALTER TABLE `actividades` DISABLE KEYS */;
INSERT INTO `actividades` VALUES (1,'INSTALACION','Instalación de internet','2021-09-16 03:42:40','2021-09-16 03:42:40'),(2,'NO TIENE SEÑAL',NULL,'2021-09-16 03:43:25','2021-09-16 03:43:25'),(3,'MALA SEÑAL',NULL,'2021-09-16 03:43:39','2021-09-16 03:43:39'),(4,'Corte de Fibra',NULL,'2021-10-05 01:24:05','2021-10-05 01:24:05'),(5,'Onu  quema',NULL,'2021-10-05 01:24:30','2021-10-05 01:24:30');
/*!40000 ALTER TABLE `actividades` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `backups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `backups` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `fecha` date NOT NULL,
  `nombre` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `enlace` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `backups` WRITE;
/*!40000 ALTER TABLE `backups` DISABLE KEYS */;
/*!40000 ALTER TABLE `backups` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `bitacora`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `bitacora` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `id_usuario` int(11) NOT NULL,
  `transaccion_realizada` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `ip_dispositivo` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=169 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `bitacora` WRITE;
/*!40000 ALTER TABLE `bitacora` DISABLE KEYS */;
INSERT INTO `bitacora` VALUES (1,1,'Rol editado con el id: 1','186.32.65.55','2021-09-09 14:22:38','2021-09-09 14:22:38'),(2,1,'Se creo una sucursal con el nombre: SUCURSAL APOPA','186.32.65.55','2021-09-09 15:26:50','2021-09-09 15:26:50'),(3,1,'Rol creado','186.32.65.55','2021-09-09 15:30:17','2021-09-09 15:30:17'),(4,1,'Rol creado','186.32.65.55','2021-09-09 15:30:51','2021-09-09 15:30:51'),(5,1,'Rol editado con el id: 3','186.32.65.55','2021-09-09 15:31:26','2021-09-09 15:31:26'),(6,1,'Usuario creado con el rol: Digitador','186.32.65.55','2021-09-09 15:31:59','2021-09-09 15:31:59'),(7,1,'Usuario editado con  id: 2 y rol: 3','186.32.65.55','2021-09-09 15:32:34','2021-09-09 15:32:34'),(8,1,'Se creo velocidad para el internet','45.167.0.5','2021-09-09 21:19:14','2021-09-09 21:19:14'),(9,1,'Se creo velocidad para el internet','45.167.0.5','2021-09-09 21:19:28','2021-09-09 21:19:28'),(10,1,'Se creo velocidad para el internet','45.167.0.5','2021-09-09 21:19:40','2021-09-09 21:19:40'),(11,1,'Usuario creado con el rol: Digitador','186.32.65.55','2021-09-09 23:09:24','2021-09-09 23:09:24'),(12,1,'Cliente creado','186.32.65.55','2021-09-09 23:20:52','2021-09-09 23:20:52'),(13,1,'Cliente creado','186.32.65.55','2021-09-09 23:22:44','2021-09-09 23:22:44'),(14,1,'Cliente creado','186.32.65.55','2021-09-09 23:26:00','2021-09-09 23:26:00'),(15,1,'Se creo servicio de internet para el cliente id: 3 con numero de contrato: 000002','186.32.65.55','2021-09-09 23:26:00','2021-09-09 23:26:00'),(16,1,'Cliente creado','186.32.65.55','2021-09-09 23:30:14','2021-09-09 23:30:14'),(17,1,'Se creo servicio de internet para el cliente id: 1 con numero de contrato: 000003','186.32.65.55','2021-09-09 23:30:14','2021-09-09 23:30:14'),(18,1,'Correlativo con nombre: cliente editado','186.32.65.55','2021-09-09 23:31:49','2021-09-09 23:31:49'),(19,1,'Correlativo con nombre: inter editado','186.32.65.55','2021-09-09 23:31:58','2021-09-09 23:31:58'),(20,1,'Cliente creado','186.32.65.55','2021-09-09 23:34:40','2021-09-09 23:34:40'),(21,1,'Se creo servicio de internet para el cliente id: 1 con numero de contrato: 000002','186.32.65.55','2021-09-09 23:34:40','2021-09-09 23:34:40'),(22,3,'Cliente creado','45.167.0.5','2021-09-09 23:45:41','2021-09-09 23:45:41'),(23,3,'Se creo servicio de internet para el cliente id: 2 con numero de contrato: 000003','45.167.0.5','2021-09-09 23:45:41','2021-09-09 23:45:41'),(24,1,'Rol editado con el id: 3','45.167.0.5','2021-09-10 00:45:59','2021-09-10 00:45:59'),(25,3,'Se edito servicio de internet para el cliente id: 1','45.167.0.5','2021-09-10 00:48:01','2021-09-10 00:48:01'),(26,3,'Se edito servicio de internet para el cliente id: 2','45.167.0.5','2021-09-10 00:49:57','2021-09-10 00:49:57'),(27,1,'Se edito servicio de internet para el cliente id: 1','159.203.179.42','2021-09-10 08:44:45','2021-09-10 08:44:45'),(28,1,'Permiso creado','186.32.65.55','2021-09-10 17:51:11','2021-09-10 17:51:11'),(29,1,'Rol editado con el id: 1','186.32.65.55','2021-09-10 17:51:25','2021-09-10 17:51:25'),(30,1,'Backup creado','186.32.65.55','2021-09-10 18:01:01','2021-09-10 18:01:01'),(31,1,'Backup creado','45.167.0.5','2021-09-10 20:34:37','2021-09-10 20:34:37'),(32,1,'Se edito servicio de internet para el cliente id: 1','186.32.65.55','2021-09-12 03:26:16','2021-09-12 03:26:16'),(33,1,'Se edito servicio de internet para el cliente id: 2','186.32.65.55','2021-09-12 03:26:36','2021-09-12 03:26:36'),(34,1,'Se edito servicio de internet para el cliente id: 1','186.32.65.55','2021-09-12 03:36:29','2021-09-12 03:36:29'),(35,1,'Se edito servicio de internet para el cliente id: 1','186.32.65.55','2021-09-12 03:37:27','2021-09-12 03:37:27'),(36,1,'Se edito servicio de internet para el cliente id: 1','186.32.65.55','2021-09-12 21:43:26','2021-09-12 21:43:26'),(37,1,'Se edito servicio de internet para el cliente id: 2','186.32.65.55','2021-09-12 21:43:37','2021-09-12 21:43:37'),(38,1,'Backup creado','186.32.65.55','2021-09-13 00:25:18','2021-09-13 00:25:18'),(39,1,'Se edito servicio de internet para el cliente id: 1','186.32.65.55','2021-09-13 20:31:15','2021-09-13 20:31:15'),(40,1,'Se edito servicio de internet para el cliente id: 1','186.32.65.55','2021-09-13 20:31:35','2021-09-13 20:31:35'),(41,1,'Se edito servicio de internet para el cliente id: 2','186.32.65.55','2021-09-13 20:31:47','2021-09-13 20:31:47'),(42,2,'Cliente creado','186.32.65.55','2021-09-13 20:51:03','2021-09-13 20:51:03'),(43,2,'Se creo servicio de internet para el cliente id: 3 con numero de contrato: 000004','186.32.65.55','2021-09-13 20:51:03','2021-09-13 20:51:03'),(44,2,'Cliente creado','186.32.65.55','2021-09-13 21:16:33','2021-09-13 21:16:33'),(45,2,'Se creo servicio de tv para el cliente id: 4 con numero de contrato: 000002','186.32.65.55','2021-09-13 21:16:33','2021-09-13 21:16:33'),(46,2,'Cliente creado','186.32.65.55','2021-09-13 21:28:33','2021-09-13 21:28:33'),(47,2,'Se creo servicio de internet para el cliente id: 5 con numero de contrato: 000005','186.32.65.55','2021-09-13 21:28:34','2021-09-13 21:28:34'),(48,1,'Rol editado con el id: 2','186.32.65.55','2021-09-13 21:35:49','2021-09-13 21:35:49'),(49,1,'Rol editado con el id: 2','186.32.65.55','2021-09-13 21:36:01','2021-09-13 21:36:01'),(50,2,'Cliente creado','186.32.65.55','2021-09-13 21:37:12','2021-09-13 21:37:12'),(51,2,'Se creo servicio de internet para el cliente id: 6 con numero de contrato: 000006','186.32.65.55','2021-09-13 21:37:12','2021-09-13 21:37:12'),(52,2,'Cliente creado','186.32.65.55','2021-09-13 21:45:50','2021-09-13 21:45:50'),(53,2,'Se creo servicio de internet para el cliente id: 7 con numero de contrato: 000007','186.32.65.55','2021-09-13 21:45:50','2021-09-13 21:45:50'),(54,1,'Cobrador creado: Oficina','138.219.13.133','2021-09-15 16:10:57','2021-09-15 16:10:57'),(55,1,'Permiso creado','138.219.13.133','2021-09-15 23:41:17','2021-09-15 23:41:17'),(56,1,'Rol editado con el id: 1','138.219.13.133','2021-09-15 23:41:39','2021-09-15 23:41:39'),(57,1,'Producto creado: INSTALACION DE INTERNET','138.219.13.133','2021-09-16 00:04:05','2021-09-16 00:04:05'),(58,1,'Producto creado: ONU INTERNET','138.219.13.133','2021-09-16 00:04:46','2021-09-16 00:04:46'),(59,1,'Producto creado: ONU CATV','138.219.13.133','2021-09-16 00:05:13','2021-09-16 00:05:13'),(60,1,'Producto creado: RECARGO INTERNET','138.219.13.133','2021-09-16 00:05:44','2021-09-16 00:05:44'),(61,1,'Producto creado: RECARGO TELEVISION','138.219.13.133','2021-09-16 00:06:03','2021-09-16 00:06:03'),(62,1,'Tecnico creado: PEDRO','138.219.13.133','2021-09-16 00:06:24','2021-09-16 00:06:24'),(63,1,'Tecnico creado: JUAN ANTONIO','138.219.13.133','2021-09-16 00:06:36','2021-09-16 00:06:36'),(64,1,'Cliente creado','186.32.65.55','2021-09-16 00:08:54','2021-09-16 00:08:54'),(65,1,'Se creo servicio de internet para el cliente id: 8 con numero de contrato: 000008','186.32.65.55','2021-09-16 00:08:55','2021-09-16 00:08:55'),(66,1,'Correlativo con nombre: cof editado','186.32.65.55','2021-09-16 00:24:41','2021-09-16 00:24:41'),(67,1,'Correlativo con nombre: cof editado','186.32.65.55','2021-09-16 02:22:37','2021-09-16 02:22:37'),(68,1,'Correlativo con nombre: ccf editado','186.32.65.55','2021-09-16 02:22:43','2021-09-16 02:22:43'),(69,1,'Cobrador editada : Oficina','186.32.65.55','2021-09-16 02:23:11','2021-09-16 02:23:11'),(70,1,'Cobrador editada : Oficina','186.32.65.55','2021-09-16 02:26:56','2021-09-16 02:26:56'),(71,1,'Cobrador editada : Oficina','138.219.13.133','2021-09-16 02:27:18','2021-09-16 02:27:18'),(72,1,'Correlativo con nombre: cof editado','186.32.65.55','2021-09-16 02:27:31','2021-09-16 02:27:31'),(73,1,'Permiso creado','186.32.65.55','2021-09-16 03:35:36','2021-09-16 03:35:36'),(74,1,'Rol editado con el id: 1','186.32.65.55','2021-09-16 03:35:48','2021-09-16 03:35:48'),(75,1,'Actividad creada','186.32.65.55','2021-09-16 03:42:40','2021-09-16 03:42:40'),(76,1,'Actividad creada','186.32.65.55','2021-09-16 03:43:26','2021-09-16 03:43:26'),(77,1,'Actividad creada','186.32.65.55','2021-09-16 03:43:39','2021-09-16 03:43:39'),(78,1,'Correlativo con nombre: ccf editado','138.219.13.133','2021-09-16 05:48:02','2021-09-16 05:48:02'),(79,1,'Correlativo con nombre: cof editado','138.219.13.133','2021-09-16 05:48:06','2021-09-16 05:48:06'),(80,1,'Se edito servicio de internet para el cliente id: 2','186.32.65.55','2021-09-21 04:37:21','2021-09-21 04:37:21'),(81,1,'Correlativo con nombre: cof editado','138.219.13.133','2021-09-21 05:04:14','2021-09-21 05:04:14'),(82,1,'Correlativo con nombre: ccf editado','138.219.13.133','2021-09-21 05:04:18','2021-09-21 05:04:18'),(83,1,'Cobrador editada : Oficina','138.219.13.133','2021-09-21 05:04:30','2021-09-21 05:04:30'),(84,1,'Se edito servicio de internet para el cliente id: 1','138.219.13.133','2021-09-21 05:05:54','2021-09-21 05:05:54'),(85,1,'Factura eliminado con  id: 4','186.32.65.55','2021-09-21 05:42:24','2021-09-21 05:42:24'),(86,1,'Factura eliminado con  id: 5','186.32.65.55','2021-09-21 05:43:21','2021-09-21 05:43:21'),(87,1,'Cliente creado','138.219.13.133','2021-09-21 06:10:42','2021-09-21 06:10:42'),(88,1,'Se creo servicio de internet para el cliente id: 9 con numero de contrato: 000009','138.219.13.133','2021-09-21 06:10:42','2021-09-21 06:10:42'),(89,1,'Se creo servicio de tv para el cliente id: 9 con numero de contrato: 000003','138.219.13.133','2021-09-21 06:10:42','2021-09-21 06:10:42'),(90,1,'Backup creado','186.32.65.55','2021-09-24 04:42:31','2021-09-24 04:42:31'),(91,1,'Contrato id: 1 cambio a inactivo','186.32.65.55','2021-09-24 04:52:07','2021-09-24 04:52:07'),(92,1,'Contrato id: 1 cambio a activo','186.32.65.55','2021-09-24 04:52:24','2021-09-24 04:52:24'),(93,1,'Contrato id: 1 cambio a inactivo','186.32.65.55','2021-09-24 04:54:54','2021-09-24 04:54:54'),(94,1,'Se creo servicio de internet para el cliente id: 1 con numero de contrato: 000010','186.32.65.55','2021-09-24 04:59:04','2021-09-24 04:59:04'),(95,1,'Contrato id: 9 cambio a inactivo','186.32.65.55','2021-09-24 04:59:32','2021-09-24 04:59:32'),(96,1,'Contrato id: 9 cambio a activo','186.32.65.55','2021-09-24 05:00:06','2021-09-24 05:00:06'),(97,1,'Contrato id: 9 cambio a inactivo','186.32.65.55','2021-09-24 05:00:15','2021-09-24 05:00:15'),(98,1,'Contrato id: 9 cambio a activo','186.32.65.55','2021-09-24 05:00:26','2021-09-24 05:00:26'),(99,1,'Suspension creada: 1','186.32.65.55','2021-09-24 05:01:18','2021-09-24 05:01:18'),(100,1,'Suspension editada con el número: 000001','186.32.65.55','2021-09-24 05:02:02','2021-09-24 05:02:02'),(101,1,'Servicio suspendido con la suspensión: 000001','138.219.13.133','2021-09-24 05:08:08','2021-09-24 05:08:08'),(102,1,'Contrato id: 9 cambio a activo','138.219.13.133','2021-09-24 05:08:59','2021-09-24 05:08:59'),(103,1,'Suspension editada con el número: 000001','186.32.65.55','2021-09-24 05:14:19','2021-09-24 05:14:19'),(104,1,'Suspension editada con el número: 000001','186.32.65.55','2021-09-24 05:14:26','2021-09-24 05:14:26'),(105,1,'Servicio suspendido con la suspensión: 000001','186.32.65.55','2021-09-24 05:17:01','2021-09-24 05:17:01'),(106,1,'Contrato id: 9 cambio a activo','186.32.65.55','2021-09-24 05:18:00','2021-09-24 05:18:00'),(107,1,'Servicio suspendido con la suspensión: 000001','186.32.65.55','2021-09-24 05:18:15','2021-09-24 05:18:15'),(108,1,'Contrato id: 9 cambio a activo','186.32.65.55','2021-09-24 05:20:06','2021-09-24 05:20:06'),(109,1,'Servicio suspendido con la suspensión: 000001','186.32.65.55','2021-09-24 05:20:42','2021-09-24 05:20:42'),(110,1,'Contrato id: 9 cambio a activo','186.32.65.55','2021-09-24 05:21:01','2021-09-24 05:21:01'),(111,1,'Servicio suspendido con la suspensión: 000001','186.32.65.55','2021-09-24 05:30:30','2021-09-24 05:30:30'),(112,1,'Reconexion creada: 1','186.32.65.55','2021-09-24 05:34:03','2021-09-24 05:34:03'),(113,1,'Reconexion editada: 000001','186.32.65.55','2021-09-24 05:35:35','2021-09-24 05:35:35'),(114,1,'Contrato id: 9 cambio a activo','186.32.65.55','2021-09-24 05:36:26','2021-09-24 05:36:26'),(115,1,'Traslado creado: 1','186.32.65.55','2021-09-24 05:38:33','2021-09-24 05:38:33'),(116,1,'Traslado editada con el id: 000001','186.32.65.55','2021-09-24 05:39:20','2021-09-24 05:39:20'),(117,1,'Cliente editada con el id: 1','186.32.65.55','2021-09-24 05:39:31','2021-09-24 05:39:31'),(118,1,'Permiso creado','186.32.65.55','2021-09-24 22:36:34','2021-09-24 22:36:34'),(119,1,'Rol editado con el id: 1','186.32.65.55','2021-09-24 22:36:44','2021-09-24 22:36:44'),(120,1,'Se creo FACTURA: 000006','138.219.13.133','2021-10-05 00:43:34','2021-10-05 00:43:34'),(121,1,'Se creo FACTURA: 000007','138.219.13.133','2021-10-05 00:47:17','2021-10-05 00:47:17'),(122,1,'Se creo FACTURA: 000008','138.219.13.133','2021-10-05 00:48:59','2021-10-05 00:48:59'),(123,1,'Se creo FACTURA: 000009','138.219.13.133','2021-10-05 00:49:36','2021-10-05 00:49:36'),(124,1,'Se anulo FACTURA: 000009','138.219.13.133','2021-10-05 00:53:46','2021-10-05 00:53:46'),(125,1,'Se anulo FACTURA: 000008','138.219.13.133','2021-10-05 00:53:54','2021-10-05 00:53:54'),(126,1,'Se creo FACTURA: 000010','138.219.13.133','2021-10-05 01:02:11','2021-10-05 01:02:11'),(127,1,'Se creo FACTURA: 000011','138.219.13.133','2021-10-05 01:06:45','2021-10-05 01:06:45'),(128,1,'Producto creado: INSTALACION DE INTERNET 20MB','138.219.13.133','2021-10-05 01:09:11','2021-10-05 01:09:11'),(129,1,'Orden creada: 000001','138.219.13.133','2021-10-05 01:14:47','2021-10-05 01:14:47'),(130,1,'Orden editada con el número: 000001','138.219.13.133','2021-10-05 01:18:33','2021-10-05 01:18:33'),(131,1,'Actividad creada','138.219.13.133','2021-10-05 01:24:05','2021-10-05 01:24:05'),(132,1,'Actividad creada','138.219.13.133','2021-10-05 01:24:30','2021-10-05 01:24:30'),(133,1,'Se creo FACTURA: 000012','138.219.13.133','2021-10-05 01:29:18','2021-10-05 01:29:18'),(134,1,'Se elimino FACTURA: 000012','138.219.13.133','2021-10-05 01:35:16','2021-10-05 01:35:16'),(135,1,'Correlativo con nombre: cof editado','138.219.13.133','2021-10-05 01:35:35','2021-10-05 01:35:35'),(136,1,'Correlativo con nombre: cof editado','138.219.13.133','2021-10-05 01:35:52','2021-10-05 01:35:52'),(137,1,'Se creo velocidad para el internet','138.219.13.133','2021-10-05 01:41:20','2021-10-05 01:41:20'),(138,1,'Usuario editado con  id: 1 y rol: 1','45.167.0.5','2021-10-18 05:00:05','2021-10-18 05:00:05'),(139,1,'Se edito servicio de internet para el cliente: 000002','45.167.0.5','2021-10-18 05:55:54','2021-10-18 05:55:54'),(140,1,'Se edito servicio de internet para el cliente: 000001','45.167.0.5','2021-10-18 06:00:50','2021-10-18 06:00:50'),(141,1,'Backup creado','138.219.13.133','2021-10-28 05:14:34','2021-10-28 05:14:34'),(142,1,'Backup creado','127.0.0.1','2021-10-29 07:42:02','2021-10-29 07:42:02'),(143,1,'Backup creado','127.0.0.1','2021-10-29 07:46:14','2021-10-29 07:46:14'),(144,1,'Backup creado','127.0.0.1','2021-10-29 07:49:12','2021-10-29 07:49:12'),(145,1,'Backup creado','127.0.0.1','2021-10-31 02:12:01','2021-10-31 02:12:01'),(146,1,'Backup creado','127.0.0.1','2021-10-31 02:13:03','2021-10-31 02:13:03'),(147,1,'Backup id:55 eliminado','127.0.0.1','2021-10-31 02:16:48','2021-10-31 02:16:48'),(148,1,'Backup id:51 eliminado','127.0.0.1','2021-10-31 02:18:55','2021-10-31 02:18:55'),(149,1,'Backup id:52 eliminado','127.0.0.1','2021-10-31 02:19:01','2021-10-31 02:19:01'),(150,1,'Backup creado','127.0.0.1','2021-10-31 02:20:15','2021-10-31 02:20:15'),(151,1,'Backup creado','127.0.0.1','2021-10-31 03:19:27','2021-10-31 03:19:27'),(152,1,'Backup creado','127.0.0.1','2021-10-31 04:11:28','2021-10-31 04:11:28'),(153,1,'Backup creado','127.0.0.1','2021-10-31 04:11:36','2021-10-31 04:11:36'),(154,1,'Backup creado','127.0.0.1','2021-10-31 04:15:03','2021-10-31 04:15:03'),(155,1,'Backup id:60 eliminado','127.0.0.1','2021-10-31 04:15:23','2021-10-31 04:15:23'),(156,1,'Backup id:56 eliminado','127.0.0.1','2021-10-31 04:15:47','2021-10-31 04:15:47'),(157,1,'Backup id:57 eliminado','127.0.0.1','2021-10-31 04:15:59','2021-10-31 04:15:59'),(158,1,'Backup creado','127.0.0.1','2021-10-31 04:16:29','2021-10-31 04:16:29'),(159,1,'Backup creado','127.0.0.1','2021-10-31 04:27:13','2021-10-31 04:27:13'),(160,1,'Backup creado','127.0.0.1','2021-10-31 04:27:15','2021-10-31 04:27:15'),(161,1,'Backup creado','127.0.0.1','2021-10-31 04:27:27','2021-10-31 04:27:27'),(162,1,'Backup creado','127.0.0.1','2021-11-01 03:32:05','2021-11-01 03:32:05'),(163,1,'Backup creado','127.0.0.1','2021-11-01 03:32:35','2021-11-01 03:32:35'),(164,1,'Backup creado','127.0.0.1','2021-11-03 00:37:48','2021-11-03 00:37:48'),(165,1,'Backup creado','127.0.0.1','2021-11-03 00:43:02','2021-11-03 00:43:02'),(166,1,'Backup creado','127.0.0.1','2021-11-03 00:43:05','2021-11-03 00:43:05'),(167,1,'Backup creado','127.0.0.1','2021-11-03 00:43:16','2021-11-03 00:43:16'),(168,1,'Backup creado','127.0.0.1','2021-11-03 00:43:31','2021-11-03 00:43:31');
/*!40000 ALTER TABLE `bitacora` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `clientes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `clientes` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `codigo` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `nombre` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `dui` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `nit` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `fecha_nacimiento` date DEFAULT NULL,
  `telefono1` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `telefono2` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `id_municipio` int(11) NOT NULL,
  `dirreccion` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `dirreccion_cobro` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `ocupacion` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `condicion_lugar` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `nombre_dueno` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `numero_registro` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `giro` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `colilla` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tipo_documento` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `referencia1` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `telefo1` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `referencia2` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `telefo2` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `referencia3` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `telefo3` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `tv` int(11) NOT NULL,
  `internet` int(11) NOT NULL,
  `cordenada` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `nodo` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `activo` int(11) NOT NULL,
  `id_sucursal` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `clientes_email_unique` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `clientes` WRITE;
/*!40000 ALTER TABLE `clientes` DISABLE KEYS */;
INSERT INTO `clientes` VALUES (1,'000001','JOSE ALBERTO HERNÁNDEZ',NULL,'00000000-0','0000-000000-0','1995-10-28','7882-8383',NULL,180,'Col. San maria local #20','Col. Brisas del paraiso','1','1','JOSE ALBERTO',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,0,1,NULL,NULL,1,1,'2021-09-09 23:34:40','2021-10-18 06:00:49'),(2,'000002','DURJAN DIOMIDES ALVARADO LEIVA','durjan.alvarado94@gmail.com','44646464-6','6466-666666-6','1994-09-05','7743-8467','7777-7777',261,'Barrio el lcalvario Cll. Doctor Garay casa #15','Barrio el lcalvario Cll. Doctor Garay casa #15','1','1','Durjan',NULL,NULL,'1','1','Melvin alvarado','5465-4646','Moises Alvarado','4545-5555','Andrea Aleman','4558-8558',0,1,NULL,NULL,1,1,'2021-09-09 23:45:41','2021-10-18 05:55:54'),(3,'000003','ARIEL ROBINSON','Ariel68roson@gmail.com','05075022-0','1509-199710-1','1997-09-15','7421-0508',NULL,127,'Caserio Juan Miguel casa #103 poloros','Caserio Juan Miguel casa #103 poloros','1','1','Marta Villalta de Rodriguez',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,0,1,NULL,NULL,1,1,'2021-09-13 20:51:03','2021-09-13 20:51:03'),(4,'000004','MARTA APARICIO','martaparicio1992@gmail.com','04378921-2','0309-199210-1','1992-09-03','7635-8090',NULL,182,'Av. Los almendros calle 3.a Block 5f casa #83','Av. Los almendros calle 3.a Block 5f casa #83','2','2','Juan de Jesús Mejía',NULL,NULL,'2','1',NULL,NULL,NULL,NULL,NULL,NULL,1,0,NULL,NULL,1,1,'2021-09-13 21:16:33','2021-09-13 21:16:33'),(5,'000005','NESTER CÓRDOBA','nestercórdoba$x@gmail.com','05456812-1','2305-198810-0','1988-05-23','7000-2121',NULL,168,'Av. Los mangos  Residencial salinas casa #7','Av. Los mangos  Residencial salinas casa #7','1','1','Nester Diomides Córdoba',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,0,1,NULL,NULL,1,1,'2021-09-13 21:28:33','2021-09-13 21:28:33'),(6,'000006','DANIEL ERNESTO CORDERO','danielcordero73@gmail.com','02309450-4','2802-199111-1','1991-02-28','7345-0808',NULL,187,'Caserío piedra azul calle mariatul casa#32','Caserío piedra azul calle mariatul casa#32','3','1','Jesús de león Díaz',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,0,1,NULL,NULL,1,1,'2021-09-13 21:37:12','2021-09-13 21:37:12'),(7,'000007','ROXANA PORTILLO DE LEÓN','roxanadeleon32@gmail.com','06543082-3','2204-198631-2','1986-04-22','7667-8998',NULL,198,'Ciudad altos de san pedro pol. 12 casa#7','Ciudad altos de san pedro pol. 12 casa#7','1','1','Walter León',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,0,1,NULL,NULL,1,1,'2021-09-13 21:45:50','2021-09-13 21:45:50'),(8,'000008','JOSE ROGRIGUES',NULL,'53423434-3','0000-000000-0','1995-10-28','7324-4523',NULL,180,'Calle militar apopa #02933','Calle militar apopa #02933','1','1','JOSE ROGRIGUES',NULL,NULL,'1','1',NULL,NULL,NULL,NULL,NULL,NULL,0,1,NULL,NULL,1,1,'2021-09-16 00:08:54','2021-09-16 00:08:54'),(9,'000009','MELVIN LUJANDIO ALVARADO LEIVA','melvin94@gmail.com','62666464-6','6664-646464-6','1996-01-18','1311-1113','1313-1313',180,'B. El calvario pasaje 3 casa #25','B. El calvario pasaje 3 casa #25','1','1','Melvin',NULL,NULL,'3','1','Durjan Alvarado','5464-6465','Moises Alvarado','5644-6546','Juan Antonio','5466-4444',1,1,NULL,NULL,1,1,'2021-09-21 06:10:42','2021-09-21 06:10:42');
/*!40000 ALTER TABLE `clientes` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `cobradors`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cobradors` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `nombre` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `resolucion` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `fecha` date DEFAULT NULL,
  `serie` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `recibo_desde` int(11) DEFAULT NULL,
  `recibo_hasta` int(11) DEFAULT NULL,
  `recibo_ultimo` int(11) DEFAULT NULL,
  `cof_desde` int(11) DEFAULT NULL,
  `cof_hasta` int(11) DEFAULT NULL,
  `cof_ultimo` int(11) DEFAULT NULL,
  `ccf_desde` int(11) DEFAULT NULL,
  `ccf_hasta` int(11) DEFAULT NULL,
  `ccf_ultimo` int(11) DEFAULT NULL,
  `activo` int(11) DEFAULT NULL,
  `id_sucursal` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `cobradors` WRITE;
/*!40000 ALTER TABLE `cobradors` DISABLE KEYS */;
INSERT INTO `cobradors` VALUES (1,'Oficina','ALDU','2021-09-15','Al0000',1,10000,8,NULL,NULL,NULL,NULL,NULL,NULL,1,1,'2021-09-15 16:10:57','2021-10-05 01:02:11');
/*!40000 ALTER TABLE `cobradors` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `correlativos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `correlativos` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `nombre` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `resolucion` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `fecha` date DEFAULT NULL,
  `serie` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `desde` int(11) DEFAULT NULL,
  `hasta` int(11) DEFAULT NULL,
  `ultimo` int(11) DEFAULT NULL,
  `cantidad` int(11) DEFAULT NULL,
  `id_sucursal` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `correlativos` WRITE;
/*!40000 ALTER TABLE `correlativos` DISABLE KEYS */;
INSERT INTO `correlativos` VALUES (1,'cof',NULL,NULL,NULL,1,10000,11,10000,1,'2021-09-09 14:20:40','2021-10-05 01:35:52'),(2,'ccf',NULL,NULL,NULL,1,10000,0,10000,1,'2021-09-09 14:20:40','2021-09-21 05:04:18'),(3,'cliente',NULL,NULL,NULL,NULL,NULL,9,NULL,1,'2021-09-09 14:20:40','2021-09-21 06:10:42'),(4,'tv',NULL,NULL,NULL,NULL,NULL,2,NULL,1,'2021-09-09 14:20:40','2021-09-21 06:10:42'),(5,'inter',NULL,NULL,NULL,NULL,NULL,9,NULL,1,'2021-09-09 14:20:40','2021-09-24 04:59:04'),(6,'orden',NULL,NULL,NULL,NULL,NULL,1,NULL,1,'2021-09-09 14:20:40','2021-10-05 01:14:47'),(7,'traslado',NULL,NULL,NULL,NULL,NULL,1,NULL,1,'2021-09-09 14:20:40','2021-09-24 05:38:33'),(8,'reconexion',NULL,NULL,NULL,NULL,NULL,1,NULL,1,'2021-09-09 14:20:40','2021-09-24 05:34:03'),(9,'suspension',NULL,NULL,NULL,NULL,NULL,1,NULL,1,'2021-09-09 14:20:40','2021-09-24 05:01:18');
/*!40000 ALTER TABLE `correlativos` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `departamentos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `departamentos` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `nombre` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `departamentos` WRITE;
/*!40000 ALTER TABLE `departamentos` DISABLE KEYS */;
INSERT INTO `departamentos` VALUES (1,'Ahuachapán',NULL,NULL),(2,'Cabañas',NULL,NULL),(3,'Chalatenango',NULL,NULL),(4,'Cuscatlán',NULL,NULL),(5,'La Libertad',NULL,NULL),(6,'La Paz',NULL,NULL),(7,'La Unión',NULL,NULL),(8,'Morazán',NULL,NULL),(9,'San Miguel',NULL,NULL),(10,'San Salvador',NULL,NULL),(11,'San Vicente',NULL,NULL),(12,'Santa Ana',NULL,NULL),(13,'Sonsonate',NULL,NULL),(14,'Usulután',NULL,NULL);
/*!40000 ALTER TABLE `departamentos` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `factura_detalles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `factura_detalles` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `id_factura` int(11) NOT NULL,
  `id_producto` int(11) NOT NULL,
  `cantidad` double(8,2) NOT NULL,
  `precio` double(8,2) NOT NULL,
  `subtotal` double(8,2) NOT NULL,
  `descuento` double(8,2) DEFAULT NULL,
  `exento` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `factura_detalles` WRITE;
/*!40000 ALTER TABLE `factura_detalles` DISABLE KEYS */;
INSERT INTO `factura_detalles` VALUES (1,3,3,2.00,10.50,21.00,NULL,NULL,'2021-09-21 05:24:17','2021-09-21 05:24:17'),(2,3,1,1.00,10.00,10.00,NULL,NULL,'2021-09-21 05:24:17','2021-09-21 05:24:17'),(4,11,4,1.00,3.00,3.00,NULL,NULL,'2021-10-05 01:06:45','2021-10-05 01:06:45');
/*!40000 ALTER TABLE `factura_detalles` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `facturas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `facturas` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `id_usuario` int(11) NOT NULL,
  `id_cliente` int(11) NOT NULL,
  `id_cobrador` int(11) DEFAULT NULL,
  `sumas` double(8,2) DEFAULT NULL,
  `iva` double(8,2) DEFAULT NULL,
  `subtotal` double(8,2) DEFAULT NULL,
  `suma_gravada` double(8,2) DEFAULT NULL,
  `venta_exenta` double(8,2) DEFAULT NULL,
  `retencion` double(8,2) DEFAULT NULL,
  `percepcion` double(8,2) DEFAULT NULL,
  `total_menos_retencion` double(8,2) DEFAULT NULL,
  `total_menos_percepcion` double(8,2) DEFAULT NULL,
  `total` double(8,2) DEFAULT NULL,
  `tipo_pago` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `tipo` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `serie` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `tipo_documento` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `numero_documento` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `impresa` int(11) NOT NULL,
  `cuota` int(11) NOT NULL,
  `anulada` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `id_sucursal` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `facturas` WRITE;
/*!40000 ALTER TABLE `facturas` DISABLE KEYS */;
INSERT INTO `facturas` VALUES (1,1,1,1,15.00,0.00,15.00,15.00,0.00,NULL,NULL,NULL,NULL,15.00,'BITCOIN','FACTURA',NULL,'1','000001',0,1,'0',1,'2021-09-21 05:21:16','2021-09-21 05:21:16'),(2,1,1,1,30.00,0.00,30.00,30.00,0.00,NULL,NULL,NULL,NULL,30.00,'BITCOIN','FACTURA',NULL,'1','000002',0,1,'1',1,'2021-09-21 05:22:46','2021-09-21 05:47:08'),(3,1,2,1,31.00,0.00,0.00,0.00,31.00,NULL,NULL,NULL,NULL,31.00,'BITCOIN','FACTURA',NULL,'1','000003',0,0,'0',1,'2021-09-21 05:24:17','2021-09-21 05:24:17'),(6,1,9,1,11.99,0.00,11.99,11.99,0.00,NULL,NULL,NULL,NULL,11.99,'EFEC','FACTURA',NULL,'1','000006',0,1,'0',1,'2021-10-05 00:43:34','2021-10-05 00:43:34'),(7,1,9,1,15.00,0.00,15.00,15.00,0.00,NULL,NULL,NULL,NULL,15.00,'EFEC','FACTURA',NULL,'1','000007',0,1,'0',1,'2021-10-05 00:47:17','2021-10-05 00:47:17'),(8,1,9,1,11.99,0.00,11.99,11.99,0.00,NULL,NULL,NULL,NULL,11.99,'EFEC','FACTURA',NULL,'1','000008',0,1,'1',1,'2021-10-05 00:48:59','2021-10-05 00:53:54'),(9,1,9,1,15.00,0.00,15.00,15.00,0.00,NULL,NULL,NULL,NULL,15.00,'EFEC','FACTURA',NULL,'1','000009',0,1,'1',1,'2021-10-05 00:49:36','2021-10-05 00:53:46'),(10,1,9,1,11.99,0.00,11.99,11.99,0.00,NULL,NULL,NULL,NULL,11.99,'BITCOIN','FACTURA',NULL,'1','000010',0,1,'0',1,'2021-10-05 01:02:11','2021-10-05 01:02:11'),(11,1,9,1,3.00,0.00,0.00,0.00,3.00,NULL,NULL,NULL,NULL,3.00,'EFEC','FACTURA',NULL,'1','000011',0,0,'0',1,'2021-10-05 01:06:45','2021-10-05 01:06:45');
/*!40000 ALTER TABLE `facturas` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `failed_jobs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `failed_jobs` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `uuid` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `connection` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `exception` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `failed_jobs` WRITE;
/*!40000 ALTER TABLE `failed_jobs` DISABLE KEYS */;
/*!40000 ALTER TABLE `failed_jobs` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `internets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `internets` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `id_cliente` int(11) NOT NULL,
  `numero_contrato` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `fecha_instalacion` date DEFAULT NULL,
  `costo_instalacion` double(8,2) DEFAULT NULL,
  `fecha_primer_fact` date DEFAULT NULL,
  `cuota_mensual` double(8,2) NOT NULL,
  `prepago` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `dia_gene_fact` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `contrato_vence` date DEFAULT NULL,
  `periodo` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `cortesia` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `velocidad` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `onu` int(11) DEFAULT NULL,
  `onu_wifi` int(11) DEFAULT NULL,
  `cable_red` int(11) DEFAULT NULL,
  `router` int(11) DEFAULT NULL,
  `marca` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `modelo` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `mac` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `serie` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `recepcion` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `trasmision` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `ip` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `identificador` int(11) NOT NULL,
  `activo` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `internets` WRITE;
/*!40000 ALTER TABLE `internets` DISABLE KEYS */;
INSERT INTO `internets` VALUES (1,1,'000001','2021-10-18',0.00,'2021-10-18',17.99,NULL,'18','2022-03-24','6',NULL,'4 MB',1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,2,'2021-09-09 23:34:40','2021-10-18 06:00:50'),(2,2,'000002','2021-08-09',20.00,'2021-09-11',14.99,NULL,'18','2022-09-09','12',NULL,'4 MB',1,NULL,1,NULL,'HUAWEI','hw200','as:ad:as:tg:df:','12345678',NULL,NULL,NULL,1,1,'2021-09-09 23:45:41','2021-10-18 05:55:54'),(3,3,'000003','2021-08-05',30.00,'2021-09-10',30.00,NULL,'14','2021-11-05','3',NULL,'5 MB',NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,'2021-09-13 20:51:03','2021-09-13 20:51:03'),(4,5,'000004','2021-08-18',30.00,'2021-09-10',25.00,NULL,'15','2021-11-18','3',NULL,'5 MB',NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,'2021-09-13 21:28:34','2021-09-13 21:28:34'),(5,6,'000005','2021-08-02',30.00,'2021-09-03',25.00,NULL,'15','2022-02-02','6',NULL,'5 MB',NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,'2021-09-13 21:37:12','2021-09-13 21:37:12'),(6,7,'000006','2021-08-06',30.00,'2021-09-12',25.00,NULL,'14','2022-08-06','12',NULL,'5 MB',NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,'2021-09-13 21:45:50','2021-09-13 21:45:50'),(7,8,'000007','2021-09-14',10.00,'2021-09-15',29.80,NULL,'15','2022-09-14','12',NULL,'5 MB',NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,'2021-09-16 00:08:55','2021-09-16 00:08:55'),(8,9,'000008','2021-08-21',10.00,'2021-09-21',11.99,NULL,'21','2022-08-21','12','1','5 MB',NULL,NULL,NULL,NULL,'HUAWEI','hw200','sd:sd:Er:RT:','2146466464',NULL,NULL,NULL,1,1,'2021-09-21 06:10:42','2021-09-21 06:10:42'),(9,1,'000009','2021-10-18',0.00,'2021-10-18',17.99,NULL,'18','2022-03-24','6',NULL,'4 MB',1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,'2021-09-24 04:59:04','2021-10-18 06:00:50');
/*!40000 ALTER TABLE `internets` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `migrations` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=26 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `migrations` WRITE;
/*!40000 ALTER TABLE `migrations` DISABLE KEYS */;
INSERT INTO `migrations` VALUES (1,'2014_10_12_000000_create_users_table',1),(2,'2014_10_12_100000_create_password_resets_table',1),(3,'2019_08_19_000000_create_failed_jobs_table',1),(4,'2021_05_18_001341_create_permission_tables',1),(5,'2021_05_21_020143_create_bitacora_table',1),(6,'2021_05_29_001126_create_tecnicos_table',1),(7,'2021_05_29_122619_create_actividades_table',1),(8,'2021_05_29_124339_create_ordenes_table',1),(9,'2021_05_29_130842_create_suspensiones_table',1),(10,'2021_05_29_131807_create_traslados_table',1),(11,'2021_05_29_133038_create_tvs_table',1),(12,'2021_05_29_134452_create_internets_table',1),(13,'2021_05_29_135612_create_clientes_table',1),(14,'2021_05_30_122839_create_departamentos_table',1),(15,'2021_05_30_122854_create_municipios_table',1),(16,'2021_05_30_230506_create_reconexions_table',1),(17,'2021_06_04_004953_create_correlativos_table',1),(18,'2021_06_05_093125_create_cobradors_table',1),(19,'2021_07_16_212230_create_abonos_table',1),(20,'2021_08_02_210736_create_sucursals_table',1),(21,'2021_08_11_154807_create_facturas_table',1),(22,'2021_08_12_180957_create_productos_table',1),(23,'2021_08_24_221419_create_factura_detalles_table',1),(24,'2021_09_08_211401_create_velocidades_table',1),(25,'2021_09_10_134135_create_backups_table',2);
/*!40000 ALTER TABLE `migrations` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `model_has_permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `model_has_permissions` (
  `permission_id` bigint(20) unsigned NOT NULL,
  `model_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `model_id` bigint(20) unsigned NOT NULL,
  PRIMARY KEY (`permission_id`,`model_id`,`model_type`),
  KEY `model_has_permissions_model_id_model_type_index` (`model_id`,`model_type`),
  CONSTRAINT `model_has_permissions_permission_id_foreign` FOREIGN KEY (`permission_id`) REFERENCES `permissions` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `model_has_permissions` WRITE;
/*!40000 ALTER TABLE `model_has_permissions` DISABLE KEYS */;
/*!40000 ALTER TABLE `model_has_permissions` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `model_has_roles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `model_has_roles` (
  `role_id` bigint(20) unsigned NOT NULL,
  `model_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `model_id` bigint(20) unsigned NOT NULL,
  PRIMARY KEY (`role_id`,`model_id`,`model_type`),
  KEY `model_has_roles_model_id_model_type_index` (`model_id`,`model_type`),
  CONSTRAINT `model_has_roles_role_id_foreign` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `model_has_roles` WRITE;
/*!40000 ALTER TABLE `model_has_roles` DISABLE KEYS */;
INSERT INTO `model_has_roles` VALUES (1,'App\\Models\\User',1),(3,'App\\Models\\User',2),(3,'App\\Models\\User',3);
/*!40000 ALTER TABLE `model_has_roles` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `municipios`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `municipios` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `id_departamento` int(11) NOT NULL,
  `nombre` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=263 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `municipios` WRITE;
/*!40000 ALTER TABLE `municipios` DISABLE KEYS */;
INSERT INTO `municipios` VALUES (1,1,'Ahuachapán',NULL,NULL),(2,1,'Apaneca',NULL,NULL),(3,1,'Atiquizaya',NULL,NULL),(4,1,'Concepción de Ataco',NULL,NULL),(5,1,'El Refugio',NULL,NULL),(6,1,'Guaymango',NULL,NULL),(7,1,'Jujutla',NULL,NULL),(8,1,'San Francisco Menéndez',NULL,NULL),(9,1,'San Lorenzo',NULL,NULL),(10,1,'San Pedro Puxtla',NULL,NULL),(11,1,'Tacuba',NULL,NULL),(12,1,'Turín',NULL,NULL),(13,2,'Cinquera',NULL,NULL),(14,2,'Dolores',NULL,NULL),(15,2,'Guacotecti',NULL,NULL),(16,2,'Ilobasco',NULL,NULL),(17,2,'Jutiapa',NULL,NULL),(18,2,'San Isidro',NULL,NULL),(19,2,'Sensuntepeque',NULL,NULL),(20,2,'Tejutepeque',NULL,NULL),(21,2,'Victoria',NULL,NULL),(22,3,'Agua Caliente',NULL,NULL),(23,3,'Arcatao',NULL,NULL),(24,3,'Azacualpa',NULL,NULL),(25,3,'Chalatenango',NULL,NULL),(26,3,'Citalá',NULL,NULL),(27,3,'Comalapa',NULL,NULL),(28,3,'Concepción Quezaltepeque',NULL,NULL),(29,3,'Dulce Nombre de María',NULL,NULL),(30,3,'El Carrizal',NULL,NULL),(31,3,'El Paraíso',NULL,NULL),(32,3,'La Laguna',NULL,NULL),(33,3,'La Palma',NULL,NULL),(34,3,'La Reina',NULL,NULL),(35,3,'Las Vueltas',NULL,NULL),(36,3,'Nombre de Jesús',NULL,NULL),(37,3,'Nueva Concepción',NULL,NULL),(38,3,'Nueva Trinidad',NULL,NULL),(39,3,'Ojos de Agua',NULL,NULL),(40,3,'Potonico',NULL,NULL),(41,3,'San Antonio de la Cruz',NULL,NULL),(42,3,'San Antonio Los Ranchos',NULL,NULL),(43,3,'San Fernando',NULL,NULL),(44,3,'San Francisco Lempa',NULL,NULL),(45,3,'San Francisco Morazán',NULL,NULL),(46,3,'San Ignacio',NULL,NULL),(47,3,'San Isidro Labrador',NULL,NULL),(48,3,'San José Cancasque',NULL,NULL),(49,3,'San José Las Flores',NULL,NULL),(50,3,'San Luis del Carmen',NULL,NULL),(51,3,'San Miguel de Mercedes',NULL,NULL),(52,3,'San Rafael',NULL,NULL),(53,3,'Santa Rita',NULL,NULL),(54,3,'Tejutla',NULL,NULL),(55,4,'Candelaria',NULL,NULL),(56,4,'Cojutepeque',NULL,NULL),(57,4,'El Carmen',NULL,NULL),(58,4,'El Rosario',NULL,NULL),(59,4,'Monte San Juan',NULL,NULL),(60,4,'Oratorio de Concepción',NULL,NULL),(61,4,'San Bartolomé Perulapía',NULL,NULL),(62,4,'San Cristóbal',NULL,NULL),(63,4,'San José Guayabal',NULL,NULL),(64,4,'San Pedro Perulapán',NULL,NULL),(65,4,'San Rafael Cedros',NULL,NULL),(66,4,'San Ramón',NULL,NULL),(67,4,'Santa Cruz Analquito',NULL,NULL),(68,4,'Santa Cruz Michapa',NULL,NULL),(69,4,'Suchitoto',NULL,NULL),(70,4,'Tenancingo',NULL,NULL),(71,5,'Antiguo Cuscatlán',NULL,NULL),(72,5,'Chiltiupán',NULL,NULL),(73,5,'Ciudad Arce',NULL,NULL),(74,5,'Colón',NULL,NULL),(75,5,'Comasagua',NULL,NULL),(76,5,'Huizúcar',NULL,NULL),(77,5,'Jayaque',NULL,NULL),(78,5,'Jicalapa',NULL,NULL),(79,5,'La Libertad',NULL,NULL),(80,5,'Nuevo Cuscatlán',NULL,NULL),(81,5,'Opico',NULL,NULL),(82,5,'Quezaltepeque',NULL,NULL),(83,5,'Sacacoyo',NULL,NULL),(84,5,'San José Villanueva',NULL,NULL),(85,5,'San Matías',NULL,NULL),(86,5,'San Pablo Tacachico',NULL,NULL),(87,5,'Santa Tecla',NULL,NULL),(88,5,'Talnique',NULL,NULL),(89,5,'Tamanique',NULL,NULL),(90,5,'Teotepeque',NULL,NULL),(91,5,'Tepecoyo',NULL,NULL),(92,5,'Zaragoza',NULL,NULL),(93,6,'Cuyultitán',NULL,NULL),(94,6,'El Rosario',NULL,NULL),(95,6,'Jerusalén',NULL,NULL),(96,6,'Mercedes La Ceiba',NULL,NULL),(97,6,'Olocuilta',NULL,NULL),(98,6,'Paraíso de Osorio',NULL,NULL),(99,6,'San Antonio Masahuat',NULL,NULL),(100,6,'San Emigdio',NULL,NULL),(101,6,'San Francisco Chinameca',NULL,NULL),(102,6,'San Juan Nonualco',NULL,NULL),(103,6,'San Juan Talpa',NULL,NULL),(104,6,'San Juan Tepezontes',NULL,NULL),(105,6,'San Luis La Herradura',NULL,NULL),(106,6,'San Luis Talpa',NULL,NULL),(107,6,'San Miguel Tepezontes',NULL,NULL),(108,6,'San Pedro Masahuat',NULL,NULL),(109,6,'San Pedro Nonualco',NULL,NULL),(110,6,'San Rafael Obrajuelo',NULL,NULL),(111,6,'Santa María Ostuma',NULL,NULL),(112,6,'Santiago Nonualco',NULL,NULL),(113,6,'Tapalhuaca',NULL,NULL),(114,6,'Zacatecoluca',NULL,NULL),(115,7,'Anamorós',NULL,NULL),(116,7,'Bolívar',NULL,NULL),(117,7,'Concepción de Oriente',NULL,NULL),(118,7,'Conchagua',NULL,NULL),(119,7,'El Carmen',NULL,NULL),(120,7,'El Sauce',NULL,NULL),(121,7,'Intipucá',NULL,NULL),(122,7,'La Unión',NULL,NULL),(123,7,'Lislique',NULL,NULL),(124,7,'Meanguera del Golfo',NULL,NULL),(125,7,'Nueva Esparta',NULL,NULL),(126,7,'Pasaquina',NULL,NULL),(127,7,'Polorós',NULL,NULL),(128,7,'San Alejo',NULL,NULL),(129,7,'San José',NULL,NULL),(130,7,'Santa Rosa de Lima',NULL,NULL),(131,7,'Yayantique',NULL,NULL),(132,7,'Yucuaiquín',NULL,NULL),(133,8,'Arambala',NULL,NULL),(134,8,'Cacaopera',NULL,NULL),(135,8,'Chilanga',NULL,NULL),(136,8,'Corinto',NULL,NULL),(137,8,'Delicias de Concepción',NULL,NULL),(138,8,'El Divisadero',NULL,NULL),(139,8,'El Rosario',NULL,NULL),(140,8,'Gualococti',NULL,NULL),(141,8,'Guatajiagua',NULL,NULL),(142,8,'Joateca',NULL,NULL),(143,8,'Jocoaitique',NULL,NULL),(144,8,'Jocoro',NULL,NULL),(145,8,'Lolotiquillo',NULL,NULL),(146,8,'Meanguera',NULL,NULL),(147,8,'Osicala',NULL,NULL),(148,8,'Perquín',NULL,NULL),(149,8,'San Carlos',NULL,NULL),(150,8,'San Fernando',NULL,NULL),(151,8,'San Francisco Gotera',NULL,NULL),(152,8,'San Isidro',NULL,NULL),(153,8,'San Simón',NULL,NULL),(154,8,'Sensembra',NULL,NULL),(155,8,'Sociedad',NULL,NULL),(156,8,'Torola',NULL,NULL),(157,8,'Yamabal',NULL,NULL),(158,8,'Yoloaiquín',NULL,NULL),(159,9,'Carolina',NULL,NULL),(160,9,'Chapeltique',NULL,NULL),(161,9,'Chinameca',NULL,NULL),(162,9,'Chirilagua',NULL,NULL),(163,9,'Ciudad Barrios',NULL,NULL),(164,9,'Comacarán',NULL,NULL),(165,9,'El Tránsito',NULL,NULL),(166,9,'Lolotique',NULL,NULL),(167,9,'Moncagua',NULL,NULL),(168,9,'Nueva Guadalupe',NULL,NULL),(169,9,'Nuevo Edén de San Juan',NULL,NULL),(170,9,'Quelepa',NULL,NULL),(171,9,'San Antonio',NULL,NULL),(172,9,'San Gerardo',NULL,NULL),(173,9,'San Jorge',NULL,NULL),(174,9,'San Luis de la Reina',NULL,NULL),(175,9,'San Miguel',NULL,NULL),(176,9,'San Rafael Oriente',NULL,NULL),(177,9,'Sesori',NULL,NULL),(178,9,'Uluazapa',NULL,NULL),(179,10,'Aguilares',NULL,NULL),(180,10,'Apopa',NULL,NULL),(181,10,'Ayutuxtepeque',NULL,NULL),(182,10,'Cuscatancingo',NULL,NULL),(183,10,'Delgado',NULL,NULL),(184,10,'El Paisnal',NULL,NULL),(185,10,'Guazapa',NULL,NULL),(186,10,'Ilopango',NULL,NULL),(187,10,'Mejicanos',NULL,NULL),(188,10,'Nejapa',NULL,NULL),(189,10,'Panchimalco',NULL,NULL),(190,10,'Rosario de Mora',NULL,NULL),(191,10,'San Marcos',NULL,NULL),(192,10,'San Martín',NULL,NULL),(193,10,'San Salvador',NULL,NULL),(194,10,'Santiago Texacuangos',NULL,NULL),(195,10,'Santo Tomás',NULL,NULL),(196,10,'Soyapango',NULL,NULL),(197,10,'Tonacatepeque',NULL,NULL),(198,11,'Apastepeque',NULL,NULL),(199,11,'Guadalupe',NULL,NULL),(200,11,'San Cayetano Istepeque',NULL,NULL),(201,11,'San Esteban Catarina',NULL,NULL),(202,11,'San Ildefonso',NULL,NULL),(203,11,'San Lorenzo',NULL,NULL),(204,11,'San Sebastián',NULL,NULL),(205,11,'San Vicente',NULL,NULL),(206,11,'Santa Clara',NULL,NULL),(207,11,'Santo Domingo',NULL,NULL),(208,11,'Tecoluca',NULL,NULL),(209,11,'Tepetitán',NULL,NULL),(210,11,'Verapaz',NULL,NULL),(211,12,'Candelaria de la Frontera',NULL,NULL),(212,12,'Chalchuapa',NULL,NULL),(213,12,'Coatepeque',NULL,NULL),(214,12,'El Congo',NULL,NULL),(215,12,'El Porvenir',NULL,NULL),(216,12,'Masahuat',NULL,NULL),(217,12,'Metapán',NULL,NULL),(218,12,'San Antonio Pajonal',NULL,NULL),(219,12,'San Sebastián Salitrillo',NULL,NULL),(220,12,'Santa Ana',NULL,NULL),(221,12,'Santa Rosa Guachipilín',NULL,NULL),(222,12,'Santiago de la Frontera',NULL,NULL),(223,12,'Texistepeque',NULL,NULL),(224,13,'Acajutla',NULL,NULL),(225,13,'Armenia',NULL,NULL),(226,13,'Caluco',NULL,NULL),(227,13,'Cuisnahuat',NULL,NULL),(228,13,'Izalco',NULL,NULL),(229,13,'Juayúa',NULL,NULL),(230,13,'Nahuizalco',NULL,NULL),(231,13,'Nahulingo',NULL,NULL),(232,13,'Salcoatitán',NULL,NULL),(233,13,'San Antonio del Monte',NULL,NULL),(234,13,'San Julián',NULL,NULL),(235,13,'Santa Catarina Masahuat',NULL,NULL),(236,13,'Santa Isabel Ishuatán',NULL,NULL),(237,13,'Santo Domingo',NULL,NULL),(238,13,'Sonsonate',NULL,NULL),(239,13,'Sonzacate',NULL,NULL),(240,14,'Alegría',NULL,NULL),(241,14,'Berlín',NULL,NULL),(242,14,'California',NULL,NULL),(243,14,'Concepción Batres',NULL,NULL),(244,14,'El Triunfo',NULL,NULL),(245,14,'Ereguayquín',NULL,NULL),(246,14,'Estanzuelas',NULL,NULL),(247,14,'Jiquilisco',NULL,NULL),(248,14,'Jucuapa',NULL,NULL),(249,14,'Jucuarán',NULL,NULL),(250,14,'Mercedes Umaña',NULL,NULL),(251,14,'Nueva Granada',NULL,NULL),(252,14,'Ozatlán',NULL,NULL),(253,14,'Puerto El Triunfo',NULL,NULL),(254,14,'San Agustín',NULL,NULL),(255,14,'San Buenaventura',NULL,NULL),(256,14,'San Dionisio',NULL,NULL),(257,14,'San Francisco Javier',NULL,NULL),(258,14,'Santa Elena',NULL,NULL),(259,14,'Santa María',NULL,NULL),(260,14,'Santiago de María',NULL,NULL),(261,14,'Tecapán',NULL,NULL),(262,14,'Usulután',NULL,NULL);
/*!40000 ALTER TABLE `municipios` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `ordenes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ordenes` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `numero` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `id_cliente` int(11) NOT NULL,
  `id_usuario` int(11) NOT NULL,
  `id_tecnico` int(11) NOT NULL,
  `id_actividad` int(11) NOT NULL,
  `observacion` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `recepcion` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `tx` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `snr` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `fecha_trabajo` date DEFAULT NULL,
  `tipo_servicio` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `soporte` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `ordenes` WRITE;
/*!40000 ALTER TABLE `ordenes` DISABLE KEYS */;
INSERT INTO `ordenes` VALUES (1,'000001',9,1,1,2,'no tiene acceso a internet','-20',NULL,NULL,'2021-10-04','Internet',NULL,'2021-10-05 01:14:47','2021-10-05 01:18:33');
/*!40000 ALTER TABLE `ordenes` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `password_resets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `password_resets` (
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  KEY `password_resets_email_index` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `password_resets` WRITE;
/*!40000 ALTER TABLE `password_resets` DISABLE KEYS */;
/*!40000 ALTER TABLE `password_resets` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `permissions` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `guard_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `permissions_name_guard_name_unique` (`name`,`guard_name`)
) ENGINE=InnoDB AUTO_INCREMENT=66 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `permissions` WRITE;
/*!40000 ALTER TABLE `permissions` DISABLE KEYS */;
INSERT INTO `permissions` VALUES (1,'Administracion','web','2021-09-09 14:20:40','2021-09-09 14:20:40'),(2,'Configuracion','web','2021-09-09 14:20:40','2021-09-09 14:20:40'),(3,'Clientes','web','2021-09-09 14:20:40','2021-09-09 14:20:40'),(4,'Abonos','web','2021-09-09 14:20:40','2021-09-09 14:20:40'),(5,'Reportes','web','2021-09-09 14:20:40','2021-09-09 14:20:40'),(6,'Facturacion','web','2021-09-09 14:20:40','2021-09-09 14:20:40'),(7,'Productos','web','2021-09-09 14:20:40','2021-09-09 14:20:40'),(8,'Usuarios','web','2021-09-09 14:20:40','2021-09-09 14:20:40'),(9,'Roles','web','2021-09-09 14:20:40','2021-09-09 14:20:40'),(10,'Permisos','web','2021-09-09 14:20:40','2021-09-09 14:20:40'),(11,'bitacora','web','2021-09-09 14:20:40','2021-09-09 14:20:40'),(12,'Actividades','web','2021-09-09 14:20:40','2021-09-09 14:20:40'),(13,'Tecnicos','web','2021-09-09 14:20:40','2021-09-09 14:20:40'),(14,'Correlativo','web','2021-09-09 14:20:40','2021-09-09 14:20:40'),(15,'correlativo_edit','web','2021-09-09 14:20:40','2021-09-09 14:20:40'),(16,'Cobradores','web','2021-09-09 14:20:40','2021-09-09 14:20:40'),(17,'create_cobrador','web','2021-09-09 14:20:40','2021-09-09 14:20:40'),(18,'edit_cobrador','web','2021-09-09 14:20:40','2021-09-09 14:20:40'),(19,'destroy_cobrador','web','2021-09-09 14:20:40','2021-09-09 14:20:40'),(20,'Sucursales','web','2021-09-09 14:20:40','2021-09-09 14:20:40'),(21,'create_sucursal','web','2021-09-09 14:20:40','2021-09-09 14:20:40'),(22,'edit_sucursal','web','2021-09-09 14:20:40','2021-09-09 14:20:40'),(23,'destroy_sucursal','web','2021-09-09 14:20:40','2021-09-09 14:20:40'),(24,'Velocidades','web','2021-09-09 14:20:40','2021-09-09 14:20:40'),(25,'create_velocidad','web','2021-09-09 14:20:40','2021-09-09 14:20:40'),(26,'edit_velocidad','web','2021-09-09 14:20:40','2021-09-09 14:20:40'),(27,'destroy_velocidad','web','2021-09-09 14:20:40','2021-09-09 14:20:40'),(28,'index_cliente','web','2021-09-09 14:20:40','2021-09-09 14:20:40'),(29,'create_cliente','web','2021-09-09 14:20:40','2021-09-09 14:20:40'),(30,'edit_cliente','web','2021-09-09 14:20:40','2021-09-09 14:20:40'),(31,'destroy_cliente','web','2021-09-09 14:20:40','2021-09-09 14:20:40'),(32,'contrato_cliente','web','2021-09-09 14:20:40','2021-09-09 14:20:40'),(33,'contrato_activo','web','2021-09-09 14:20:40','2021-09-09 14:20:40'),(34,'contrato_vista','web','2021-09-09 14:20:40','2021-09-09 14:20:40'),(35,'contrato_create','web','2021-09-09 14:20:40','2021-09-09 14:20:40'),(36,'contrato_store','web','2021-09-09 14:20:40','2021-09-09 14:20:40'),(37,'Ordenes','web','2021-09-09 14:20:40','2021-09-09 14:20:40'),(38,'create_orden','web','2021-09-09 14:20:40','2021-09-09 14:20:40'),(39,'edit_orden','web','2021-09-09 14:20:40','2021-09-09 14:20:40'),(40,'destroy_orden','web','2021-09-09 14:20:40','2021-09-09 14:20:40'),(41,'Suspensiones','web','2021-09-09 14:20:40','2021-09-09 14:20:40'),(42,'create_suspension','web','2021-09-09 14:20:40','2021-09-09 14:20:40'),(43,'edit_suspension','web','2021-09-09 14:20:40','2021-09-09 14:20:40'),(44,'destroy_suspension','web','2021-09-09 14:20:40','2021-09-09 14:20:40'),(45,'Reconexiones','web','2021-09-09 14:20:40','2021-09-09 14:20:40'),(46,'create_reconexion','web','2021-09-09 14:20:40','2021-09-09 14:20:40'),(47,'edit_reconexion','web','2021-09-09 14:20:40','2021-09-09 14:20:40'),(48,'destroy_reconexion','web','2021-09-09 14:20:40','2021-09-09 14:20:40'),(49,'Traslados','web','2021-09-09 14:20:40','2021-09-09 14:20:40'),(50,'create_traslado','web','2021-09-09 14:20:40','2021-09-09 14:20:40'),(51,'edit_traslado','web','2021-09-09 14:20:40','2021-09-09 14:20:40'),(52,'destroy_traslado','web','2021-09-09 14:20:40','2021-09-09 14:20:40'),(53,'estado_cuenta','web','2021-09-09 14:20:40','2021-09-09 14:20:40'),(54,'estado_cuenta_pdf','web','2021-09-09 14:20:40','2021-09-09 14:20:40'),(55,'abonos_pendientes','web','2021-09-09 14:20:40','2021-09-09 14:20:40'),(56,'abonos_pendientes_pdf','web','2021-09-09 14:20:40','2021-09-09 14:20:40'),(57,'reporte_cliente','web','2021-09-09 14:20:40','2021-09-09 14:20:40'),(58,'destroy_factura','web','2021-09-09 14:20:40','2021-09-09 14:20:40'),(59,'create_producto','web','2021-09-09 14:20:40','2021-09-09 14:20:40'),(60,'edit_producto','web','2021-09-09 14:20:40','2021-09-09 14:20:40'),(61,'destroy_producto','web','2021-09-09 14:20:40','2021-09-09 14:20:40'),(62,'backup','web','2021-09-10 17:51:11','2021-09-10 17:51:11'),(63,'reporte_factura','web','2021-09-15 23:41:17','2021-09-15 23:41:17'),(64,'anular_factura','web','2021-09-16 03:35:36','2021-09-16 03:35:36'),(65,'carga_datos','web','2021-09-24 22:36:33','2021-09-24 22:36:33');
/*!40000 ALTER TABLE `permissions` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `productos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `productos` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `nombre` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `marca` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `minimo` int(11) DEFAULT NULL,
  `activo` int(11) DEFAULT NULL,
  `exento` int(11) DEFAULT NULL,
  `costo` double(8,2) DEFAULT NULL,
  `precio` double(8,2) NOT NULL,
  `tipo_producto` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `id_sucursal` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `productos` WRITE;
/*!40000 ALTER TABLE `productos` DISABLE KEYS */;
INSERT INTO `productos` VALUES (1,'INSTALACION DE INTERNET',NULL,NULL,1,NULL,NULL,10.00,'Servicio',1,'2021-09-16 00:04:05','2021-09-16 00:04:05'),(2,'ONU INTERNET','HUAWIE',NULL,1,NULL,NULL,10.50,'Equipo',1,'2021-09-16 00:04:46','2021-09-16 00:04:46'),(3,'ONU CATV','HUAWEI',NULL,1,NULL,NULL,10.50,'Equipo',1,'2021-09-16 00:05:13','2021-09-16 00:05:13'),(4,'RECARGO INTERNET',NULL,NULL,1,NULL,NULL,3.00,'Servicio',1,'2021-09-16 00:05:44','2021-09-16 00:05:44'),(5,'RECARGO TELEVISION',NULL,NULL,1,NULL,NULL,3.00,'Servicio',1,'2021-09-16 00:06:03','2021-09-16 00:06:03'),(6,'INSTALACION DE INTERNET 20MB',NULL,NULL,1,NULL,NULL,25.00,'Servicio',1,'2021-10-05 01:09:11','2021-10-05 01:09:11');
/*!40000 ALTER TABLE `productos` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `reconexions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `reconexions` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `numero` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `id_cliente` int(11) NOT NULL,
  `id_usuario` int(11) NOT NULL,
  `id_tecnico` int(11) NOT NULL,
  `observacion` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `fecha_trabajo` date DEFAULT NULL,
  `tipo_servicio` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `contrato` int(11) DEFAULT NULL,
  `n_contrato` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `rx` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `tx` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `activado` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `reconexions` WRITE;
/*!40000 ALTER TABLE `reconexions` DISABLE KEYS */;
INSERT INTO `reconexions` VALUES (1,'000001',1,1,1,'Cancelara nueva cuota','2021-09-23','Internet',NULL,NULL,'-20',NULL,'0','2021-09-24 05:34:03','2021-09-24 05:35:35');
/*!40000 ALTER TABLE `reconexions` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `role_has_permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `role_has_permissions` (
  `permission_id` bigint(20) unsigned NOT NULL,
  `role_id` bigint(20) unsigned NOT NULL,
  PRIMARY KEY (`permission_id`,`role_id`),
  KEY `role_has_permissions_role_id_foreign` (`role_id`),
  CONSTRAINT `role_has_permissions_permission_id_foreign` FOREIGN KEY (`permission_id`) REFERENCES `permissions` (`id`) ON DELETE CASCADE,
  CONSTRAINT `role_has_permissions_role_id_foreign` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `role_has_permissions` WRITE;
/*!40000 ALTER TABLE `role_has_permissions` DISABLE KEYS */;
INSERT INTO `role_has_permissions` VALUES (1,1),(2,1),(3,1),(3,3),(4,1),(5,1),(6,1),(7,1),(8,1),(9,1),(10,1),(11,1),(12,1),(13,1),(14,1),(15,1),(16,1),(17,1),(18,1),(19,1),(20,1),(21,1),(22,1),(23,1),(24,1),(25,1),(26,1),(27,1),(28,1),(28,3),(29,1),(29,3),(30,1),(30,3),(31,1),(32,1),(33,1),(34,1),(35,1),(36,1),(37,1),(38,1),(39,1),(40,1),(41,1),(42,1),(43,1),(44,1),(45,1),(46,1),(47,1),(48,1),(49,1),(50,1),(51,1),(52,1),(53,1),(54,1),(55,1),(56,1),(57,1),(58,1),(59,1),(60,1),(61,1),(62,1),(63,1),(64,1),(65,1);
/*!40000 ALTER TABLE `role_has_permissions` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `roles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `roles` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `guard_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `roles_name_guard_name_unique` (`name`,`guard_name`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `roles` WRITE;
/*!40000 ALTER TABLE `roles` DISABLE KEYS */;
INSERT INTO `roles` VALUES (1,'Administrador','web','2021-09-09 14:20:40','2021-09-09 14:20:40'),(2,'Usuario','web','2021-09-09 15:30:17','2021-09-09 15:30:17'),(3,'Digitador','web','2021-09-09 15:30:51','2021-09-09 15:30:51');
/*!40000 ALTER TABLE `roles` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `sucursals`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sucursals` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `nombre` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `dirreccion` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `id_municipio` int(11) NOT NULL,
  `correo` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `telefono` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `web` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `sucursals` WRITE;
/*!40000 ALTER TABLE `sucursals` DISABLE KEYS */;
INSERT INTO `sucursals` VALUES (1,'SUCURSAL APOPA','Colonia Cuscatlán Block D Casa N. 16',180,'tecnnitel.sv@gmail.com','2698-4733','www.tecnnitel.sv','2021-09-09 15:26:50','2021-09-09 15:26:50');
/*!40000 ALTER TABLE `sucursals` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `suspensiones`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `suspensiones` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `numero` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `id_cliente` int(11) NOT NULL,
  `id_usuario` int(11) NOT NULL,
  `id_tecnico` int(11) NOT NULL,
  `motivo` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `fecha_trabajo` date DEFAULT NULL,
  `observaciones` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `tipo_servicio` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `suspendido` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `suspensiones` WRITE;
/*!40000 ALTER TABLE `suspensiones` DISABLE KEYS */;
INSERT INTO `suspensiones` VALUES (1,'000001',1,1,2,'Por mora','2021-09-23','Se recupero equipo','Internet',1,'2021-09-24 05:01:18','2021-09-24 05:30:30');
/*!40000 ALTER TABLE `suspensiones` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `tecnicos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tecnicos` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `nombre` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `direccion` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `telefono` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `correo` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `id_sucursal` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `tecnicos` WRITE;
/*!40000 ALTER TABLE `tecnicos` DISABLE KEYS */;
INSERT INTO `tecnicos` VALUES (1,'PEDRO',NULL,'6566-4646',NULL,1,'2021-09-16 00:06:24','2021-09-16 00:06:24'),(2,'JUAN ANTONIO',NULL,'5464-4646',NULL,1,'2021-09-16 00:06:36','2021-09-16 00:06:36');
/*!40000 ALTER TABLE `tecnicos` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `traslados`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `traslados` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `numero` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `id_cliente` int(11) NOT NULL,
  `id_usuario` int(11) NOT NULL,
  `id_tecnico` int(11) NOT NULL,
  `nueva_direccion` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `id_municipio` int(11) NOT NULL,
  `rx` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `tx` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `fecha_trabajo` date DEFAULT NULL,
  `observacion` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `tipo_servicio` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `update_direc` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `traslados` WRITE;
/*!40000 ALTER TABLE `traslados` DISABLE KEYS */;
INSERT INTO `traslados` VALUES (1,'000001',1,1,2,'Col. San maria local #20',180,'-17',NULL,'2021-09-23','Cancelara $5.25 de traslado','Internet',1,'2021-09-24 05:38:33','2021-09-24 05:39:31');
/*!40000 ALTER TABLE `traslados` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `tvs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tvs` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `id_cliente` int(11) NOT NULL,
  `numero_contrato` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `fecha_instalacion` date DEFAULT NULL,
  `costo_instalacion` double(8,2) DEFAULT NULL,
  `fecha_primer_fact` date DEFAULT NULL,
  `cuota_mensual` double(8,2) NOT NULL,
  `prepago` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `dia_gene_fact` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `contrato_vence` date DEFAULT NULL,
  `periodo` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `cortesia` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `digital` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `marca` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `serie` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `modelo` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `identificador` int(11) NOT NULL,
  `activo` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `tvs` WRITE;
/*!40000 ALTER TABLE `tvs` DISABLE KEYS */;
INSERT INTO `tvs` VALUES (1,4,'000001','2021-08-01',30.00,'2021-09-05',25.00,NULL,'15','2021-11-01','3',NULL,'1','Samsung',NULL,NULL,2,1,'2021-09-13 21:16:33','2021-09-13 21:16:33'),(2,9,'000002','2021-08-21',0.00,'2021-09-21',15.00,NULL,'21','2022-08-21','12','1',NULL,NULL,NULL,NULL,2,1,'2021-09-21 06:10:42','2021-09-21 06:10:42');
/*!40000 ALTER TABLE `tvs` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `id_rol` int(11) NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `id_sucursal` int(11) NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_email_unique` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,1,'admin','admin@admin.com',NULL,'$2y$10$5r49n1B7rDb0i2BAcm8Z7OrZqWPUoFxtSaoszaDw4nSL3fqJUWYO2',1,NULL,'2021-09-09 14:20:40','2021-10-18 05:00:05'),(2,3,'karina','karina@gmail.com',NULL,'$2y$10$TyYhn8W/lg8LM7xu0B9j0.IGXifpjMmPkRRZWPD6/WONwkLt/nK7G',1,NULL,'2021-09-09 15:31:59','2021-09-09 15:32:34'),(3,3,'durjan','durjan.alvarado94@gmail.com',NULL,'$2y$10$iiV/Znlb07iGXifoTbeMMuCK/RteoGnxA924GqJlYadgF3iNK/gnm',1,NULL,'2021-09-09 23:09:24','2021-09-09 23:09:24');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `velocidades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `velocidades` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `detalle` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `bajada` int(11) NOT NULL,
  `subida` int(11) DEFAULT NULL,
  `estado` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `velocidades` WRITE;
/*!40000 ALTER TABLE `velocidades` DISABLE KEYS */;
INSERT INTO `velocidades` VALUES (1,'3 megas',3,1,1,'2021-09-09 21:19:14','2021-09-09 21:19:14'),(2,'4 megas',4,1,1,'2021-09-09 21:19:28','2021-09-09 21:19:28'),(3,'5mb',5,2,1,'2021-09-09 21:19:40','2021-09-09 21:19:40'),(4,'15 MEGAS',15,5,1,'2021-10-05 01:41:20','2021-10-05 01:41:20');
/*!40000 ALTER TABLE `velocidades` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

